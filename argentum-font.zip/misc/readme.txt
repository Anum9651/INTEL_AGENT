                           Argentum v2.2�2002 by Rafael Dinner

This is the fourth release of the Argentum font family. The three Argentum font
styles together (including all caps + punctuation) are shareware priced at $5 (US
dollars, no foreign checks, please!), which should not exceed anyone's capacity.
Furthermore, I feel that this font is high quality (all of my fonts are created
in Adobe Illustrator with maximum accuracy). Payment covers all future versions.
Feel free to give suggestions (no purchase necessary!) and request bitmap sizes.

Contact me at school:
e-mail:
rdinner@alum.mit.edu

mail (through 8/2001):
736 Escondido Rd #335
Stanford, CA 94305-7587

HTTP (browse and download my other fonts):
http://www.stanford.edu/~rdinner/fonts.html

Argentum is available in Postscript� Type 1 and TrueType�.

Argentum is meant to be a 3-D display font to grab attention or just look slick.
You may also like using Argentum in italics. You will find that Argentum
maintains accuracy at very high resolutions, and does so with minimum complexity
of paths (=minimum disk space and RAM needed).

Here is a list of my currently completed fonts:
ArgentumBlack, ArgentumWhite, ArgentumShine
ArgentumSilver (type 3 postscript)
Daisy
Diamond
Grease
Kontrast
Reverb
RotondoSilver
StilettoBlack, StilettoSilver

Enjoy!
